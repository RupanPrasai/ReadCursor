import { sampleFunction } from '@src/sample-function';

console.log('[CEB] Example content script loaded');

void sampleFunction();
